# Starter kit · Method 20 · Accessibility quick-audit service

> Strength: High. That is our screening judgement of how well this method holds up for a beginner with $0, not an earnings forecast. Typical first-sale window: 7–21 days.

## The offer in one look
- Buyer: small website owners
- Deliverable: keyboard, contrast, labels, headings, alt-text and mobile review with prioritized fixes.
- What AI does: explain findings and draft corrected markup/alt text.
- $0 start: the free tiers of the tools used in the workshop below. Check current limits before you rely on them.
- Boundary: call it a quick audit, not legal certification.

## Practise it first
Best starter build: Build 02 · Build a local business page
- Workshop: https://open-practice.zlnew.workers.dev/earn/builds/local-page-kit/
- Practice pack: https://open-practice.zlnew.workers.dev/resources/earn/packs/02-local-page-kit.zip

## First sale, step by step
Start here: make one private sample of the deliverable (keyboard, contrast, labels, headings, alt-text and mobile review with prioritized fixes) for one real prospect (buyer: small website owners) and send it to them personally.

1. Write your offer sheet for one narrow buyer (Build 01 helps). Name five real prospects you can reach without buying a list.
2. Make one private sample with invented or public information. Never use someone's private data without permission.
3. Send five personalised messages, one at a time, each with a reason that is specific to that person. No mass messages.
4. Offer a small, bounded first job with a clear price, timeline and revision limit.
5. Deliver, run the acceptance checks below, get written approval, and ask for an honest testimonial only after real work.

## Acceptance checks (proof to keep)
- [ ] The work delivers what the offer says: keyboard, contrast, labels, headings, alt-text and mobile review with prioritized fixes
- [ ] Boundary kept: call it a quick audit, not legal certification
- [ ] The client approved the work in writing
- [ ] No invented reviews, numbers or guarantees anywhere

## Five prospects (sales practice)
| # | prospect (role or business) | why them specifically | personal first line | sent | reply |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |

## Economics
- Hours per delivery:
- Free-tier limits that could bite:
- Price, and why:
- I will reinvest when:

---

# The offer contract

Every Earn by Doing build ends with these 10 artifacts. They make very different businesses measurable, reviewable and safe to practise. Fill in one contract per offer.

## 01 · Buyer
_One specific customer and a painful job worth solving._

- Buyer: small website owners
- The painful, repeated job:
- Where I can reach five of them this week:

## 02 · Bounded offer
_Exact deliverables, exclusions, timeline and revision limit._

- Deliverables: keyboard, contrast, labels, headings, alt-text and mobile review with prioritized fixes.
- Exclusions:
- Timeline (days):
- Revisions (rounds):

## 03 · Free stack
_Primary tool plus an offline or free alternative; note current limits._

- Primary tool:
- Free or offline alternative:
- Limits checked on (date):

## 04 · Evidence
_Source log, inputs, outputs, tests and acceptance checklist._

- Where the evidence log lives:
- Acceptance checklist:

## 05 · Human gate
_Approval before publishing, messaging, spending or deletion._

- Who approves what, and how (in writing):

## 06 · Privacy
_Synthetic practice data; permission and minimisation for real data._

- Practice data used:
- Real data, with whose permission, and what I removed:

## 07 · Rights
_Provenance and commercial-use check for text, image, audio and code._

- Every asset, where it came from and whether it may be used commercially:

## 08 · Honesty
_No fake proof, invented testimonials or guaranteed-income claims._

- Claims I make, and the evidence for each: only what the acceptance checklist proves.

## 09 · Sales practice
_Five personalised prospects, not mass messages._

- Five prospects are in sales-practice.csv, each with a reason that is specific to them.

## 10 · Economics
_Time log, free-tier limits, delivery cost, price and a reinvestment trigger._

- Hours per delivery:
- Free-tier limits that could bite:
- Delivery cost:
- Price:
- I will reinvest when:

---
Open Practice · Earn by Doing · CC BY 4.0 · https://open-practice.zlnew.workers.dev/earn/
