# Build 09 · Map and prototype one workflow

Automation that nobody understands breaks the first time something unusual happens. Start with a map: every step, every decision, every place data moves. Then run the workflow by hand or with a free tool on sample data, note what failed, and write handoff notes so someone else can run it. The map is the product; the tool is a detail.

## You will make
- Process map
- Test run
- Handoff notes

## Steps
1. Read worked-example.md first. It shows a finished deliverable for an invented business.
2. Open the workshop at https://open-practice.zlnew.workers.dev/earn/builds/workflow-map/ or use template.md offline. Replace every [[blank]] with your own work.
3. Do the real-world part: the interviews, tests, approvals or hand counts the template asks for. Log each one in evidence-log.csv.
4. Run the checks in the workshop, or go through checklist.md by hand. Fix one thing at a time.
5. Fill in offer-contract.md and pick five personalised prospects in sales-practice.csv. No mass messages.
6. Record time and costs in economics.csv. Keep everything: it is your evidence.

## What is in this pack
- template.md: the blank deliverable
- worked-example.md: a finished example (invented business, labelled)
- checklist.md: the same checks the workshop runs, in plain words
- process-map.csv: a blank log for this build
- test-run.csv: a blank log for this build
- offer-contract.md: the 10 artifacts every build ends with
- sales-practice.csv, evidence-log.csv, economics.csv

## Honest limits
This pack teaches a way of working. It does not promise income. Use invented practice data until you have a real client, and get permission before using anyone else's data, media or name.

Open Practice · Earn by Doing · CC BY 4.0 · https://open-practice.zlnew.workers.dev/earn/builds/workflow-map/
