> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Clean-up plan: a hardware shop’s stock list

## Safety first
- I work on a copy named stock-clean-2026-11-04.xlsx. The original is never edited.
- Personal data: supplier phone numbers in column H. I hid column H before asking AI for formulas and never pasted any row.
- Size at the start: 1,240 rows, 9 columns

## Rules log
Problems found: duplicate products, prices typed as text, supplier names spelled three ways.

1. Merge exact duplicates — column B (product code) — why: the same code appears twice — method: sort by code, compare rows, keep the newer count
2. Convert prices to numbers — column E — why: 312 prices were text — method: =VALUE(SUBSTITUTE(E2,"$",""))
3. One spelling per supplier — column G — why: "Hardline", "Hard Line" and "HARDLINE" — method: lookup table in the tab "suppliers"

## Validation report
- Rows before: 1,240 · rows after: 1,198
- Duplicates removed: 42, listed in the tab “removed”
- Values changed: 391, listed in the tab “changes”
- Check total before: 1,240 rows of stock · after: 1,198 · difference explained: the 42 duplicates, each checked
- Spot checks (three rows compared by hand): rows 15, 402 and 1,103 match the paper stock book
- The goal works: total stock value by supplier → a pivot table on column G, total US$18,406

## Handoff
- The client receives: the cleaned copy, the rules log and this report
- The client must check: the 6 products where the two duplicate counts disagreed

## Boundary
- Nothing was deleted without being listed. The original file is untouched.
- No personal data was pasted into an AI tool.
