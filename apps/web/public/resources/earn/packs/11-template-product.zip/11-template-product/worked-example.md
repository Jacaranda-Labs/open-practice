> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Template product: a Google Sheets budget for market traders

## Product files
1. trader-budget.xlsx · the template, with tabs for daily sales, stock, home money and a weekly summary
2. START-HERE.pdf · start-here steps:
   - Step 1: open the file and choose "Make a copy"
   - Step 2: type your opening cash in the yellow cell
   - Step 3: each evening, enter the day's sales and spending
   - Step 4: move home money in the "home" tab, never from the till
   - Step 5: on Sunday, read the summary tab
3. trader-budget-example.xlsx · a month filled with invented numbers

## Licence
- You may: use it for your own business and change it however you like
- You may not: resell, share or upload the file anywhere
- Refunds: within 7 days if it does not open or work as described

## Listing copy
Title: Market Trader Budget (Google Sheets & Excel)
Description: Shop money and home money get mixed up, and the week ends without knowing if you made anything. This sheet keeps them apart and shows the answer every Sunday.
For: traders who mix shop money and home money
Included: the budget sheet, a filled example and a start-here guide
Not for: businesses with staff or VAT returns
Price: US$7

## Proof
- Origin: I built it for my aunt’s stall and used it for a year
- Validation: six traders on her row asked for a copy; four used it for a month and kept going
- Works in Google Sheets and Excel; tested on a phone and a laptop

## Boundary
- No income claims, invented reviews or sales numbers. I made every file myself.
- It is a tracking tool, not financial or tax advice.
