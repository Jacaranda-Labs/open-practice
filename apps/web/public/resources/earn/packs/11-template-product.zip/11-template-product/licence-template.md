# Licence

- You may: 
- You may not: 
- Refunds: 

Plain language beats legal-sounding language. Say only what you can enforce and what you actually own.
