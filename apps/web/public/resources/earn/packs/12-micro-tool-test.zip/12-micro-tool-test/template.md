# Micro-tool test: [[The micro-tool idea in one line]]

## Interviews
For: [[Who has the problem?]]
1. Tell me about the last time you had to deal with this: [[What do they do today instead?]].
2. [[question about how long it took]]
3. [[question about what it cost them or what they lost]]
4. [[question about what they tried]]
5. [[question about who else is involved]]

Log (no names):
- [[role]] · [[date]] · quote: “[[their words]]” · pain: [[1–5]]
- [[role]] · [[date]] · quote: “[[their words]]” · pain: [[1–5]]

## Manual prototype
For one user, by hand:
- Step 1: [[how they send you the input]]
- Step 2: [[what you do]]
- Step 3: [[what they receive and how fast]]
- Measure: [[e.g. time saved, whether they use it again next week]]

## Test plan
- Smallest tool: [[the one job it does, nothing else]] · built with [[Free tools you would build it with]]
- Success measure 1: [[a number]]
- Success measure 2: [[a number]]
- Success measure 3: [[a number]]
- Stop rule: [[e.g. if fewer than 3 of 5 users use it twice, stop or change the idea]]
- Timebox: [[number]] days

## Data and safety
[[what data it touches, where it is stored, who can see it]]

## Boundary
- Interview results are real and recorded without names. No invented users or demand.
- [[one more limit, e.g. it drafts quotes; a person checks every price]]
