# Checklist · Build 12 · Micro-tool Validation Plan

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Interviews” section
- [ ] Has a “Manual prototype” section
- [ ] Has a “Test plan” section
- [ ] Has a “Data and safety” section
- [ ] Has a “Boundary” section
- [ ] At least 5 interview questions
- [ ] At least 2 interview log lines with a pain score
- [ ] Has a stop rule with a number
- [ ] Has a timebox in days
- [ ] Mentions the idea from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 180 and 1000 words
- [ ] Did the interviews ask about what people did, not what they would buy?
- [ ] Did someone use the manual version more than once?
- [ ] Would you really stop if the stop rule is triggered?
