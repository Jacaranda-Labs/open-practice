> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Micro-tool test: a tool that turns a voice note into a printed quotation

## Interviews
For: plumbers and electricians who quote on site
1. Tell me about the last time you had to deal with this: write quotes by hand at night.
2. How long did that quote take, from the site visit to sending it?
3. Have you ever lost a job because the quote arrived late?
4. What have you tried: templates, an app, asking someone else?
5. Who else sees the quote before the customer does?

Log (no names):
- plumber · 6 November · quote: “I lose about one job a week because the quote is late” · pain: 5
- electrician · 7 November · quote: “My daughter types them on Sundays” · pain: 4
- plumber · 7 November · quote: “Customers just want a number on WhatsApp” · pain: 2

## Manual prototype
For one user, by hand:
- Step 1: he sends a voice note after the site visit
- Step 2: I type the items and prices into a quote template and check the maths
- Step 3: he receives a PDF on WhatsApp within 2 hours
- Measure: whether he sends me a second voice note within a week, and hours saved per quote

## Test plan
- Smallest tool: voice note in, draft quote out, nothing else · built with a web page, a free AI key, Cloudflare free tier
- Success measure 1: 3 of 5 tradespeople use it at least twice in two weeks
- Success measure 2: a quote takes under 10 minutes from voice note to PDF
- Success measure 3: no price errors in 10 checked quotes
- Stop rule: if fewer than 3 of 5 use it twice, stop or change the idea
- Timebox: 14 days

## Data and safety
Voice notes and quotes contain customer addresses. They are deleted after 30 days and never used to train anything.

## Boundary
- Interview results are real and recorded without names. No invented users or demand.
- It drafts quotes; a person checks every price before sending.
