# Checklist · Build 06 · Article Refresh Report

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Source log” section
- [ ] Has a “Changes” section
- [ ] Has a “Revised sections” section
- [ ] Has a “Change report” section
- [ ] Has a “Boundary” section
- [ ] At least 3 claims with a named source
- [ ] At least 3 numbered changes (before → after)
- [ ] Each claim has a date checked
- [ ] Mentions the article from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 180 and 1200 words
- [ ] Could the owner open every source you named and find the same fact?
- [ ] Did you keep the parts that were still right?
- [ ] Is the change report short enough to read on a phone?
