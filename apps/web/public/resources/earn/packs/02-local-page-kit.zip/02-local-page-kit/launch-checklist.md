# Launch checklist

- [ ] Owner approved the copy in writing
- [ ] Prices and phone number checked against the owner's list
- [ ] Loads on a phone on mobile data in under 3 seconds
- [ ] Every image is the owner's own or free to use, with alt text
- [ ] Contact button tested from a second phone
- [ ] Domain or free address registered in the owner's name
- [ ] Handoff note sent and read
