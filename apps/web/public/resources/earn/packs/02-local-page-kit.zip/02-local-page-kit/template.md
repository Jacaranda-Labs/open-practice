# Page kit: [[Business name and type]]

## Page copy
Headline: [[under 10 words: what they do and for whom]]
One line: [[one sentence a passer-by would understand]]

Services and prices:
[[Services with prices (one per line)]]

Where and when: [[Where is it, and when is it open?]]
Contact button: [[the words on the button, e.g. “WhatsApp us to book”]] → [[How should customers get in touch?]]
Proof shown on the page: [[Proof the owner has given you permission to use]]

## Demo test plan
- Phone test: [[open the demo on a phone on mobile data; how many seconds until the text shows?]]
- Contrast: [[can you read every line in sunlight?]]
- Contact test: [[press the contact button; does it open the right number with a message ready?]]
- Links: [[open every link; list any that fail]]
- Facts: the owner checked every price, the hours and the number on [[date]]

## Launch checklist
- [ ] Owner approved the copy in writing
- [ ] Prices and phone number checked against the owner's list
- [ ] Page loads on a phone in under [[number]] seconds
- [ ] Every image is the owner's own, or free to use, and has alt text
- [ ] Contact button tested from a second phone
- [ ] The domain or free web address is registered in the owner's name
- [ ] [[one more check specific to this business]]
- [ ] Handoff note sent and read

## Client handoff
- To change a price: [[the exact steps, in plain words]]
- Who owns what: [[domain, hosting account, email: all in the owner's name]]
- What may cost money later: [[e.g. a domain renewal each year; nothing else]]
- How to get help: [[how to reach you and what you charge for changes, if anything]]

## Boundary
- No invented reviews, awards or customer numbers. Only proof the owner gave permission for.
- [[one more limit, e.g. I do not run paid adverts]]
