# Checklist · Build 02 · Local Business Page Kit

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Page copy” section
- [ ] Has a “Demo test plan” section
- [ ] Has a “Launch checklist” section
- [ ] Has a “Client handoff” section
- [ ] Has a “Boundary” section
- [ ] Has a headline line
- [ ] Shows real prices or numbers
- [ ] At least 8 checklist items (- [ ] …)
- [ ] Accounts stay in the owner’s name
- [ ] No invented ratings or awards
- [ ] Mentions the business name from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 220 and 1000 words
- [ ] Did the owner check every price and the phone number themselves?
- [ ] Could the owner change a price next month without you?
- [ ] Did you test on a cheap phone on mobile data, not only on your laptop?
