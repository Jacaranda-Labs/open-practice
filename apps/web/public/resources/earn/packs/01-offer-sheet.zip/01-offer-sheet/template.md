# Offer sheet: [[What exactly will you hand over?]] for [[Who exactly is the buyer?]]

## Niche brief
- Buyer: [[Who exactly is the buyer?]]
- The job they hate: [[What painful, repeated job do they have?]]
- Where I can reach five of them this week: [[a place you can actually reach them, e.g. a market row, a group you already belong to]]
- Why me: [[What can you already do well?]]

## Problem interview
1. Tell me about the last time this happened: [[What painful, repeated job do they have?]]. What did you do?
2. [[a question about what it cost them: time, money or customers]]
3. [[a question about what they have tried already]]
4. [[a question about who decides and who pays]]
5. If this were solved, what would be different next month?

Notes after the interviews: [[what you heard, in their words, and how many said it hurts]]

## The offer
- What you get: [[What exactly will you hand over?]]
- Exclusions: [[what is not included]]
- Timeline: [[number]] days from yes to delivery
- Revisions: [[number]] rounds
- What I need from you: [[access, files or an hour of your time]]

## Price hypothesis
- First price: [[Your first price guess (with currency)]]
- Why this number: [[hours it takes × your hourly rate, or what they pay now for a worse fix]]
- How I will test it: [[e.g. say the price to five buyers and count who asks how to start]]
- I will change the price if: [[a rule, e.g. all five say yes at once → raise it next time]]

## Boundary
- No guaranteed results, no invented testimonials and no fake deadlines.
- [[one limit specific to this offer]]

## Evidence so far
[[Any evidence the problem is real (optional)]]
[[what you have checked yourself, with dates]]
