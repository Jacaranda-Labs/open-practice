# Checklist · Build 05 · Clip Pack Planner

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Clips” section
- [ ] Has a “Captions” section
- [ ] Has a “Rights log” section
- [ ] Has a “Approval sheet” section
- [ ] Has a “Boundary” section
- [ ] Every clip has start and end timestamps
- [ ] At least 3 clip hooks
- [ ] At least 3 approval lines
- [ ] Rights log covers music
- [ ] Mentions the source video from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 180 and 900 words
- [ ] Does each clip make sense to someone who never saw the full video?
- [ ] Does every caption match what was actually said?
- [ ] Do you have written permission for every person and song in the clips?
