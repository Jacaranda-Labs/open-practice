# Monthly content pack: [[Business and what it sells]]

## Content system
Real facts:
[[Real facts to draw on (one per line)]]

- Week 1 theme: [[theme]] · based on: [[fact]]
- Week 2 theme: [[theme]] · based on: [[fact]]
- Week 3 theme: [[theme]] · based on: [[fact]]
- Week 4 theme: [[theme]] · based on: [[fact]]
- Never posted: [[e.g. customer photos without a yes, prices not confirmed, other businesses]]

## Drafts
Voice: [[How does the owner talk?]]

### Week 1
[[draft under 80 words]]
Visual: [[photo or graphic idea the owner can shoot on a phone]]
Based on: [[fact]]

### Week 2
[[draft]]
Visual: [[photo or graphic idea]]
Based on: [[fact]]

### Week 3
[[draft]]
Visual: [[photo or graphic idea]]
Based on: [[fact]]

### Week 4
[[draft]]
Visual: [[photo or graphic idea]]
Based on: [[fact]]

## Approval calendar
Channel: [[Where will posts go, and how often?]]
- Drafts sent to the owner every [[day]] by [[time]]
- Owner replies by [[day]]; no reply means [[nothing is posted]]
- Posting days: [[days]]

## Measures
- [[something to count, e.g. enquiries that mention a post]]
- [[a second measure]]

## Boundary
- Every post is based on a fact the owner confirmed. No invented offers, prices or reviews.
- Nothing is posted without the owner's approval.
