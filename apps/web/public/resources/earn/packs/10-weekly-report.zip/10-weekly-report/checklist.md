# Checklist · Build 10 · Weekly Business Report

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Measures” section
- [ ] Has a “Formulas” section
- [ ] Has a “QA tests” section
- [ ] Has a “One-page report” section
- [ ] Has a “Boundary” section
- [ ] At least 4 measures tied to a decision and a formula
- [ ] Contains real spreadsheet formulas
- [ ] At least 3 QA tests with a hand count
- [ ] Mentions the business from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 180 and 1000 words
- [ ] Does every measure lead to a decision the owner actually makes?
- [ ] Did each formula match a hand count, including an odd week?
- [ ] Can the owner read the report in under a minute?
