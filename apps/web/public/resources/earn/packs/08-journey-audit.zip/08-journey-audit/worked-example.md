> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Journey audit: a driving instructor, practice audit with his permission

## Journey
Customer goal: book a first lesson
Steps taken: searched, opened the Facebook page, sent a WhatsApp, waited for a reply.

1. Searched "driving lessons Belvedere" → the page appears fourth, with no photo · evidence: 01-search.png, 10:01, 4 November
2. Opened the Facebook page → last post from March, no prices · evidence: 02-page.png, 10:03, 4 November
3. Sent "How much is a first lesson?" on WhatsApp → no automatic greeting · evidence: 03-message.png, 10:05, 4 November
4. Waited for a reply → reply after 26 hours, asking me to call · evidence: 04-reply.png, 12:11, 5 November

## Evidence pack
Problems seen: no prices anywhere, a reply after 26 hours, old posts.
Stored in: audit-instructor-nov · 4 screenshots, all from public pages or with permission

## Prioritised fixes
- Add a WhatsApp Business greeting with prices and lesson times · impact: high · effort: low · why: answers the first question instantly
- Pin a post with prices and the booking steps · impact: high · effort: low · why: the page has no prices today
- Reply within two hours on weekdays · impact: high · effort: medium · why: a learner waiting 26 hours books elsewhere
- Post one learner pass photo a month, with permission · impact: medium · effort: low · why: the page looks inactive

## Mini-demo
Top fix: a WhatsApp Business greeting
Before: silence until he is free to type, sometimes a day later.
After: "Hello! First lesson US$15, 45 minutes, Mon–Sat. Reply with a day and time and I will confirm today."

## Boundary
- Only public touchpoints were used, or the business asked for this audit. No fake enquiries that waste staff time.
- I report what I observed. I do not guess at the business's sales or numbers.
